package com.hotelbooking.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hotelbooking.models.Hotel;

@Repository
public interface HotelDao extends JpaRepository<Hotel, String> {
	@Query(value = "SELECT * from hotel h where isdeleted=0 and city=?4 and (totalavailable-?1)>(select count(*) from booking b where (checkin>=?2 and checkin<=?3) or (checkout>=?2 and checkout<=?3))", nativeQuery = true)
	List<Hotel> findAvailableHotels(int rooms, LocalDate fromdate,LocalDate todate, String city);
	
	List<Hotel> findByIsdeletedFalse();
}
