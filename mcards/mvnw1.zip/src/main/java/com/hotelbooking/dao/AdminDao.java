package com.hotelbooking.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hotelbooking.models.Admin;

@Repository
public interface AdminDao extends JpaRepository<Admin, String> {

}
