package com.hotelbooking.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelbooking.dao.BookingDao;
import com.hotelbooking.dao.GuestDao;
import com.hotelbooking.models.Booking;
import com.hotelbooking.models.Guest;

@Service
public class BookingService {

	@Autowired private BookingDao dao;
	@Autowired private GuestDao gdao;
	
	public void saveBooking(Booking booking, List<Guest> guests) {
		Booking b = dao.save(booking);
		for(Guest g : guests) {
			g.setBooking(b);
			gdao.save(g);
		}
	}
	
	@Transactional
	public void deleteBooking(int id) {
		gdao.deleteByBookingId(id);
		dao.deleteById(id);
	}
	
	public List<Booking> allBookings(){
		return dao.findAll();
	}
	
	public List<Booking> userBookings(String userid){
		return dao.findByUserUsername(userid);
	}
	
	public List<Guest> bookingGuests(int bid){
		return gdao.findByBookingId(bid);
	}
}
