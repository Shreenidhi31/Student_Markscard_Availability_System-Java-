package com.hotelbooking.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelbooking.dao.UserDao;
import com.hotelbooking.models.Hotel;
import com.hotelbooking.models.User;

@Service
public class UserService {

	@Autowired private UserDao dao;
	
	public void saveUser(User user) {
		dao.save(user);
	}
	
	public List<User> allUsers(){
		return dao.findByIsdeletedFalse();
	}
	
	public void deleteUser(String id) {
		User user = findUser(id);
		user.setIsdeleted(true);
		dao.save(user);
	}
	
	public User findUser(String userid) {
		return dao.findById(userid).get();
	}
	
	public User validate(String userid,String pwd) {
		Optional<User> user = dao.findById(userid);
		if(user.isPresent() && !user.get().isIsdeleted() && user.get().getPassword().equals(pwd)) {
			return user.get();
		}
		return null;
	}
}
