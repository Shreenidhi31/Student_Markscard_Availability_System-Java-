package com.hotelbooking.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelbooking.dao.HotelDao;
import com.hotelbooking.models.Hotel;

@Service
public class HotelService {
	
	@Autowired private HotelDao dao;
	
	public void saveHotel(Hotel hotel) {
		hotel.setId(generateHotelId());
		dao.save(hotel);
	}
	
	public List<Hotel> allHotels(){
		return dao.findByIsdeletedFalse();
	}
	
	public void deleteHotel(String id) {
		Hotel hotel = getHotelDetails(id);
		hotel.setIsdeleted(true);
		dao.save(hotel);
	}
	
	public Hotel getHotelDetails(String id) {
		return dao.findById(id).orElse(null);
	}
	
	public List<Hotel> findAvailableRooms(String city,int count,LocalDate checkin,LocalDate checkout){
		return dao.findAvailableHotels(count, checkin, checkout, city);
	}
	
	private String generateHotelId() {
		return String.format("HR%03d", dao.count()+1);
	}

}
