package com.hotelbooking.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hotelbooking.models.Hotel;
import com.hotelbooking.services.BookingService;
import com.hotelbooking.services.HotelService;
import com.hotelbooking.services.UserService;

@Controller
public class AdminController {

	@Autowired private UserService userService;
	@Autowired private HotelService hotelService;
	@Autowired private BookingService bookingService;
	
	@GetMapping("/users")
	public String allusers(Model model) {
		model.addAttribute("list", userService.allUsers());
		return "users";
	}
	
	@GetMapping("/deleteuser/{id}")
	public String deleteuser(@PathVariable("id") String id,RedirectAttributes ra) {
		userService.deleteUser(id);
		ra.addFlashAttribute("msg", "User deleted successfully");
		return "redirect:/users";
	}
	
	@GetMapping("/dashboard")
	public String dashboard() {
		return "dashboard";
	}
	
	@GetMapping("/hotels")
	public String hotels(Model model) {
		model.addAttribute("list", hotelService.allHotels());
		return "hotels";
	}
	
	@GetMapping("/deletehotel/{id}")
	public String hotels(@PathVariable("id") String id,RedirectAttributes ra) {
		hotelService.deleteHotel(id);
		ra.addFlashAttribute("msg", "Hotel deleted successfully");
		return "redirect:/hotels";
	}
	
	@GetMapping("/bookings")
	public String bookings(Model model) {
		model.addAttribute("list", bookingService.allBookings());
		return "bookings";
	}
	
	@GetMapping("/addhotel")
	public String addHotel() {
		return "addhotel";
	}
	
	@PostMapping("/addhotel")
	public String saveHotel(Hotel hotel,RedirectAttributes ra) {
		hotelService.saveHotel(hotel);
		ra.addFlashAttribute("msg", "Hotel added successfully");
		return "redirect:/hotels";
	}
}
