package com.hotelbooking.controllers;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hotelbooking.models.Admin;
import com.hotelbooking.models.Booking;
import com.hotelbooking.models.Guest;
import com.hotelbooking.models.Hotel;
import com.hotelbooking.models.User;
import com.hotelbooking.services.AdminService;
import com.hotelbooking.services.BookingService;
import com.hotelbooking.services.HotelService;
import com.hotelbooking.services.UserService;

@Controller
public class UserController {

	@Autowired private UserService userService;
	@Autowired private HttpSession session;
	@Autowired private AdminService adminService;
	@Autowired private HotelService hotelService;
	@Autowired private BookingService bookingService;
	
	@GetMapping("")
	public String home() {
		return "index";
	}

	@PostMapping("/")
	public String Validate(String userid,String pwd, String role,RedirectAttributes redirAttrs) {
		if(role.equals("Admin")) {
			Admin admin = adminService.validate(userid, pwd);
			if(admin!=null) {
				session.setAttribute("uname", "Administrator");
				session.setAttribute("role", role);
				return "redirect:/dashboard";
			}else {
				redirAttrs.addFlashAttribute("error", "Invalid username or password..!!");
				return "redirect:/";
			}
		}else {
			User user=userService.validate(userid, pwd);	
			if(user!=null) {
				session.setAttribute("uname", user.getFirstname());
				session.setAttribute("id", user.getUsername());
				session.setAttribute("role", role);
				return "redirect:/profile";
			}else {
				redirAttrs.addFlashAttribute("error", "Invalid username or password..!!");
				return "redirect:/";
			}
		}	
	}

	@GetMapping("/search")
	public String searchroom(Optional<Integer> rooms,String city,LocalDate checkin,LocalDate checkout,Model model) {
		if(city!=null) {
			List<Hotel> hotels = hotelService.findAvailableRooms(city, rooms.get(), checkin, checkout);
			model.addAttribute("list", hotels);
			model.addAttribute("found", hotels.size()>0);
		}
		return "search";
	}

	@GetMapping("/booknow")
	public String booknow(int rooms,String hid,String city,LocalDate checkin,LocalDate checkout,Model model) {
		model.addAttribute("hotel", hotelService.getHotelDetails(hid));
		model.addAttribute("guests", new Guest[rooms]);
		long days =ChronoUnit.DAYS.between(checkin, checkout);
		model.addAttribute("days", days);
		return "booknow";
	}

	@PostMapping("/bookprocess")
	public String processbooking(Booking booking,@RequestParam MultiValueMap<String,String> data,RedirectAttributes ra) {
		List<Guest> guests = new ArrayList<>();
		System.out.println(booking);
		System.out.println(data.getFirst("rooms"));
		for(int i=0;i<Integer.parseInt(data.getFirst("rooms"));i++) {
			guests.add(new Guest(
					data.get("firstname").get(i),
					data.get("lastname").get(i),
					data.get("email").get(i),
					LocalDate.parse(data.get("dob").get(i)),
					data.get("phone").get(i)));
		}
		bookingService.saveBooking(booking,guests);
		ra.addFlashAttribute("msg", "Booking successful");
		return "redirect:/mybookings";
	}

	@GetMapping("/mybookings")
	public String mybookings(Model model) {
		model.addAttribute("list", bookingService.userBookings(session.getAttribute("id").toString()));
		return "mybookings";
	}
	
	@GetMapping("/deletebooking/{id}")
	public String deletebooking(@PathVariable("id") int id,RedirectAttributes ra) {
		bookingService.deleteBooking(id);
		ra.addFlashAttribute("msg", "Booking deleted successfully");		
		return "redirect:/mybookings";
	}

	@GetMapping("/profile")
	public String profile(Model model) {
		model.addAttribute("user", userService.findUser(session.getAttribute("id").toString()));
		return "profile";
	}

	@GetMapping("/register")
	public String register() {
		return "register";
	}

	@PostMapping("/register")
	public String registerprocess(User user, RedirectAttributes ra) {
		userService.saveUser(user);
		ra.addFlashAttribute("msg", "Registered successfully");
		return "redirect:/";
	}

	@GetMapping("/logout")
	public String logout() {
		session.invalidate();
		return "redirect:/";
	}
}
